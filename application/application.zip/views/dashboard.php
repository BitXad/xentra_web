<div class="row" >
    <div class="col-md-12" >
<!--        <div class="box">
            <div class="box-header">
                <h3 class="box-title">
                    
                    
                    
                </h3>
                
            </div>
        </div>-->
        <center>
            
            <a href="<?php echo base_url("lectura/lecturas"); ?>" style="padding: 0; background: yellow" class="btn btn-facebook">
                        <img src="<?php echo base_url("resources/images/system/")."lecturas.png"; ?>" >                                              
                    </a>
            
                    <a href="<?php echo base_url("factura/cobranza"); ?>" style="padding: 0; background: yellow" class="btn btn-facebook">
                        <img src="<?php echo base_url("resources/images/system/")."facturacion.png"; ?>" >                                              
                    </a>
                    <a href="<?php echo base_url("ingreso"); ?>"  style="padding: 0; background: yellow" class="btn btn-facebook">
                        <img src="<?php echo base_url("resources/images/system/")."ingresos.png"; ?>" >                                              
                    </a>
                    <a href="<?php echo base_url("egreso"); ?>" style="padding: 0; background: yellow" class="btn btn-facebook">
                        <img src="<?php echo base_url("resources/images/system/")."egresos.png"; ?>" >                                              
                    </a>
                    <a href="" style="padding: 0; background: yellow" class="btn btn-facebook">
                        <img src="<?php echo base_url("resources/images/system/")."ventas.png"; ?>" >                                              
                    </a>
                    <a href="<?php echo base_url("reportes"); ?>" style="padding: 0; background: yellow" class="btn btn-facebook">
                        <img src="<?php echo base_url("resources/images/system/")."reportes.png"; ?>" >                                              
                    </a>
        </center>
    </div>
    <div class="col-md-12" >
        <center>
            <h1 style="font-family: Arial;">                
                AQUI VA UN GRAFICO
            </h1>
            
        </center>
    </div>
    
    <div class="col-md-12" >
        <center>
            
                    <a href="<?php echo base_url("asociado"); ?>"  style="padding: 0;">
                        <img src="<?php echo base_url("resources/images/system/")."asociados.png"; ?>" >                                              
                    </a>
                    <a href="<?php echo base_url("aporte"); ?>" style="padding: 0;">
                        <img src="<?php echo base_url("resources/images/system/")."aportes.png"; ?>" >                                              
                    </a>
                    <a href="<?php echo base_url("multum"); ?>" style="padding: 0;">
                        <img src="<?php echo base_url("resources/images/system/")."multas.png"; ?>" >                                              
                    </a>
                    <a href="<?php echo base_url("parametro"); ?>" style="padding: 0;">
                        <img src="<?php echo base_url("resources/images/system/")."parametros.png"; ?>" >                                              
                    </a>
                    <a href="" style="padding: 0;">
                        <img src="<?php echo base_url("resources/images/system/")."dosificaciones.png"; ?>" >                                              
                    </a>
                    <a href="<?php echo base_url("usuario"); ?>" style="padding: 0;">
                        <img src="<?php echo base_url("resources/images/system/")."usuarios.png"; ?>" >                                              
                    </a>
<!--                    <button style="padding: 0;">
                        <img src="<?php echo base_url("resources/images/system/")."roles.png"; ?>" >                                              
                    </button>
                    <button style="padding: 0;">
                        <img src="<?php echo base_url("resources/images/system/")."configuraciones.png"; ?>" >                                              
                    </button>-->
        </center>
                              
    </div>
</div>